<?php
    require_once '../config/conexao.php';

    //temporada/temporada.php?acao=listar

    if(!isset($_GET['acao'])) $acao="listar";
    else $acao = $_GET['acao'];

    /**
    * Ação de listar
    */
    if($acao=="listar"){
       $sql   = "SELECT a.id, a.escritor,a.id_revista, a.lido, r.isbn as revista
                    FROM autores a
                    INNER JOIN revista r ON r.id=a.id_revista";
       $query = $con->query($sql);
       $registros = $query->fetchAll();

       // print_r($registros); exit;
       require_once '../template/cabecalho.php';
       require_once 'lista_autores.php';
       require_once '../template/rodape.php';
    }
    /**
    * Ação Novo
    **/
    else if($acao == "novo"){
       $lista_revista = getRevista();

      // print_r($lista_genero); exit;
      require_once '../template/cabecalho.php';
      require_once 'form_autores.php';
      require_once '../template/rodape.php';
    }
    /**
    * Ação Gravar
    **/
    else if($acao == "gravar"){
        $registro = $_POST;

        $registro['lido'] = (isset($registro['lido']))? 1 : 0;
        // var_dump($registro);

        $sql = "INSERT INTO autores(escritor, id_revista, lido)
                  VALUES(:escritor, :id_revista, :lido)";
        $query = $con->prepare($sql);
        $result = $query->execute($registro);
        if($result){
            header('Location: ./autores.php?acao=listar&id_revista='.$registro['id_revista']);
        }else{
            print_r($registro);
            echo "Erro ao tentar inserir o registro, msg: " . print_r($query->errorInfo());
        }
    }
    /**
    * Ação Excluir
    **/
    else if($acao == "excluir"){
        $id    = $_GET['id'];
        $sql   = "DELETE FROM autores WHERE id = :id";
        $query = $con->prepare($sql);

        $query->bindParam(':id', $id);

        $result = $query->execute();
        if($result){
            header('Location: ./autores.php?acao=listar&id_revista='.$_GET['id_revista']);
        }else{
            echo "Erro ao tentar remover o resgitro de id: " . $id;
        }
    }
    /**
    * Ação Excluir
    **/
    else if($acao == "buscar"){
        $id    = $_GET['id'];
        $sql   = "SELECT * FROM autores WHERE id = :id";
        $query = $con->prepare($sql);
        $query->bindParam(':id', $id);

        $query->execute();
        $registro = $query->fetch();

        // var_dump($registro); exit;
         $lista_revista = getRevista();
        require_once '../template/cabecalho.php';
        require_once 'form_autores.php';
        require_once '../template/rodape.php';
    }
    /**
    * Ação Atualizar
    **/
    else if($acao == "atualizar"){
        $sql   = "UPDATE autores SET escritor = :escritor,
                    id_revista = :id_revista, lido = :lido WHERE id = :id";
        $query = $con->prepare($sql);

        $_POST['lido'] = (isset($_POST['lido']))? 1 : 0;

        $query->bindParam(':id', $_GET['id']);
        $query->bindParam(':escritor', $_POST['escritor']);
        $query->bindParam(':id_revista', $_POST['id_revista']);
        $query->bindParam(':lido', $_POST['lido']);
        $result = $query->execute();

        if($result){
            header('Location: ./autores.php');
        }else{
            echo "Erro ao tentar atualizar os dados" . print_r($query->errorInfo());
        }
    }

    //função que retorna a lista de gêneros cadastrados no banco
    function getRevista(){
        $sql   = "SELECT * FROM revista";
        $query = $GLOBALS['con']->query($sql);
        $lista_revista = $query->fetchAll();
        return $lista_revista;
    }
 ?>
