<?php
    if(isset($registro)) $acao = "autores.php?acao=atualizar&id=".$registro['id'];
    else $acao = "autores.php?acao=gravar";
 ?>
<div class="container">
  <form class="" action="<?php echo $acao; ?>" method="post">
    <input type="hidden" name="id_revista"
      value="<?php if(isset($registro)) echo $registro['id_revista'];
                   else echo $_GET['id_revista']; ?>">
    <div class="from-group">
     <label for="escritor">Escritor</label>
     <input id="escritor" class="form-control" type="text" name="escritor"
       value="<?php if(isset($registro)) echo $registro['escritor']; ?>" required>
    </div>
    <div class="from-group">
      <label for="id_revista">Revista</label>
      <select class="form-control" name="id_revista" required>
        <option value="">Escolha um item na lista</option>
        <?php foreach ($lista_revista as $item): ?>
          <option value="<?php echo $item['id']; ?>"
            <?php if(isset($registro) && $registro['id_revista']==$item['id']) echo "selected";?>>
            <?php echo $item['isbn']; ?>
          </option>
        <?php endforeach; ?>
      </select>
      <div class="form-check">
        <input id="completa" class="form-check-input" type="checkbox" name="lido"
          <?php if(isset($registro) && $registro['lido']==1) echo "checked"; ?>>
        <label class="form-check-label" for="completa">  Lido </label>
      </div>
    <br>
    <button class="btn btn-info" type="submit">Enviar</button>
  </form>
</div>
