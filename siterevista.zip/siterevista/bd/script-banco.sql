
CREATE TABLE editora (
                id int(11) NOT NULL,
                nome varchar(500) NOT NULL,
                categoria varchar(500) NOT NULL,
                PRIMARY KEY (id)
);


CREATE TABLE revista (
                id int(11) NOT NULL,
                ano_lancamento int(11) NOT NULL,
                isbn int(11) NOT NULL,
                valor int(11) NOT NULL,
                id_editora int(11) NOT NULL,
                revista_completa tinyint(1) NOT NULL,
                PRIMARY KEY (id)
);


CREATE TABLE autores (
                id int(11) NOT NULL,
                escritor varchar(500) NOT NULL,
                id_revista int(11) NOT NULL,
                lido BOOLEAN NOT NULL,
                PRIMARY KEY (id)
);


CREATE TABLE revista_autores (
               id int(11) NOT NULL,
               descricao varchar(100) NOT NULL,
               pagina int(11) NOT NULL,
               id_autores int(11) NOT NULL,
               lido BOOLEAN NOT NULL,
               PRIMARY KEY (id)
);

CREATE TABLE usuario (
              id int(11) NOT NULL,
              nome varchar(100) NOT NULL,
              email varchar(100) NOT NULL,
              senha varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE revista ADD CONSTRAINT editora_revista_fk
FOREIGN KEY (id_editora)
REFERENCES editora (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE autores ADD CONSTRAINT revista_autores_fk
FOREIGN KEY (id_revista)
REFERENCES revista (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE revista_autores ADD CONSTRAINT autores_revista_autores_fk
FOREIGN KEY (id_autores)
REFERENCES autores (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION;
