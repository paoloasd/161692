<?php  require_once '../template/cabecalho.php'; ?>
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include("conexao.php");
$editora = selectIdEditora($_POST["id"]);
//var_dump($pessoa);

?>
<meta charset="UTF-8">
<div class="container">
<form name="dadosEditora" action="conexao.php" method="POST">
  <div class="from-group">

          <div class="from-group">
              <label >Nome</label>
              <input type="text" name="nome" value="<?=$editora["nome"]?>" size="20"/>
          </div>
          <div class="from-group">
              <label >Categoria</label>
              <input type="text" name="categoria" value="<?=$editora["categoria"]?>" size="20"/>
          </div>
          </div>
          <div class="from-group">


                <input type="hidden" name="acao" value="alterar" />
                <input type="hidden" name="id" value="<?=$editora["id"]?>" />

                <br>
                <input class="btn btn-info" type="submit" value="Enviar" name="Enviar" />
            </div>

</div>
</form>
</div>
<?php  require_once '../template/rodape.php'; ?>
