<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(isset($_POST["acao"])){
    if($_POST["acao"]=="inserir"){
        inserirEditora();
    }
    if($_POST["acao"]=="alterar"){
        alterarEditora();
    }
    if($_POST["acao"]=="excluir"){
        excluirEditora();
    }
}

function abrirBanco(){
    $conexao = new mysqli("localhost", "root", "", "siterevista");
    return $conexao;
}

function inserirEditora(){
    $banco = abrirBanco();
    $sql = "INSERT INTO editora(nome, categoria) "
            . "VALUES ('{$_POST["nome"]}','{$_POST["categoria"]}')";
    $banco->query($sql);
    $banco->close();
    voltarIndex();
}

function alterarEditora(){
    $banco = abrirBanco();
    $sql = "UPDATE editora SET nome='{$_POST["nome"]}',"
            . "categoria='{$_POST["categoria"]}' WHERE id='{$_POST["id"]}'";
    $banco->query($sql);
    $banco->close();
    voltarIndex();
}

function excluirEditora(){
    $banco = abrirBanco();
    $sql = "DELETE FROM editora WHERE id='{$_POST["id"]}'";
    $banco->query($sql);
    $banco->close();
    voltarIndex();
}

function selectAllEditora(){
    $banco = abrirBanco();
    $sql = "SELECT * FROM editora ORDER BY nome";
    $resultado = $banco->query($sql);
    $banco->close();
    while ($row = mysqli_fetch_array($resultado)) {
        $grupo[] = $row;
    }
    return $grupo;
}

function selectIdEditora($id){
    $banco = abrirBanco();
    $sql = "SELECT * FROM editora WHERE id =".$id;
    $resultado = $banco->query($sql);
    $banco->close();
    $editora = mysqli_fetch_assoc($resultado);
    return $editora;
}

function voltarIndex(){
    header("Location:index.php");
}
