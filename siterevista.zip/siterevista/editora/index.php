<?php  require_once '../template/cabecalho.php'; ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php include("conexao.php");
      $grupo = selectAllEditora();
?>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <h2>Editora</h2>
        <a class="btn btn-primary" href="inserir.php">Novo</a>
        <table class="table table-hover table-stripped">
          <thead>
              <th>ID</th>
              <th>Nome</th>
              <th>Categoria</th>
              <th>Editar</th>
              <th>Excluir</th>
          </thead>
            <tbody>
                <?php
                    foreach ($grupo as $editora) { ?>
                    <tr>
                    <td><?=$editora["id"]?></td>
                    <td><?=($editora["nome"])?></td>
                    <td><?=$editora["categoria"]?></td>
                    <td>
                        <form name="alterar" action="alterar.php" method="POST"  >
                            <input type="hidden" name="id" value=<?=$editora["id"]?> />
                            <input type="submit" value="Editar" name="editar"  class="btn btn-success" />
                            </form>

                    </td>
                    <td>
                        <form name="excluir" action="conexao.php" method="POST" >
                            <input type="hidden" name="id" value="<?=$editora["id"]?>" />
                            <input type="hidden" name="acao" value="excluir" />
                            <input type="submit" value="Excluir" name="excluir" class="btn btn-info" />
                            </form>

                    </td>
                    </tr>
                 <?php  }
                ?>
            </tbody>
        </table>
        <a class="btn btn-dark" href="gerarPDF.php" target="_blank">Gerar relatório PDF</a>
    </body>
</html>
<?php  require_once '../template/rodape.php'; ?>
