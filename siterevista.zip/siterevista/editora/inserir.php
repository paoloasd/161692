<?php  require_once '../template/cabecalho.php';

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<h1>Editora</h1>
<meta charset="UTF-8">
<div class="container">
<form name="dadosEditora" action="conexao.php" method="POST">

            <div class="from-group">
                <label for="nome">Nome</label>
                <input id="nome" class="form-control" type="text" name="nome"
                value="<?php if(isset($registro)) echo $registro['nome']; ?>" required>
            </div>
            <div class="from-group">
                <label for="cidade">Categoria</label>
                <input id="categoria" class="form-control" type="text" name="categoria"
                value="<?php if(isset($registro)) echo $registro['categoria']; ?>" required>
            </div>
            <br>
            <div>
                <td><input type="hidden" name="acao" value="inserir" /></td>
                <td><input class="btn btn-info" type="submit" value="Enviar" name="Enviar" /></td>
            </div>



</form>
</div>
<?php  require_once '../template/rodape.php'; ?>
