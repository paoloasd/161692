<?php require_once 'template/cabecalho.php'; ?>

<section class="jumbotron text-center">
  <div class="container">
    <h1 class="jumbotron-heading">Livraria de Editoras</h1>
    <p class="lead text-muted">
      Aplicação para auxiliar na criação de escritoras.
    </p>

  </div>
</section>

<?php require_once 'template/rodape.php'; ?>
