<?php
    if(isset($registro)) $acao = "revista.php?acao=atualizar&id=".$registro['id'];
    else $acao = "revista.php?acao=gravar";
 ?>
<div class="container">
  <form class="" action="<?php echo $acao; ?>" method="post">
    <div class="from-group">
      <label for="ano_lancamento">Ano Lançamento</label>
      <input id="ano_lancamento" class="form-control" type="date" name="ano_lancamento"
        value="<?php if(isset($registro)) echo $registro['ano_lancamento']; ?>" required>
    </div>
    <div class="from-group">
      <label for="isbn">ISBN</label>
      <input id="isbn" class="form-control" type="number" name="isbn"
        value="<?php if(isset($registro)) echo $registro['isbn']; ?>" required>
    </div>
    <div class="from-group">
      <label for="valor">Valor</label>
      <input id="valor" class="form-control" type="number" name="valor"
        value="<?php if(isset($registro)) echo $registro['valor']; ?>" required>
    </div>
  <div class="from-group">
      <label for="id_editora">Editora</label>
      <select class="form-control" name="id_editora" required>
        <option value="">Escolha um item na lista</option>
        <?php foreach ($lista_editora as $item): ?>
          <option value="<?php echo $item['id']; ?>"
            <?php if(isset($registro) && $registro['id_editora']==$item['id']) echo "selected";?>>
            <?php echo $item['categoria']; ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-check">
      <input id="revista_completa" class="form-check-input" type="checkbox" name="revista_completa"
        <?php if(isset($registro) && $registro['revista_completa']==1) echo "checked"; ?>>
      <label class="form-check-label" for="revista_completa">  Revista Completa </label>
    </div>
    <br>
    <button class="btn btn-info" type="submit">Enviar</button>
  </form>
</div>
