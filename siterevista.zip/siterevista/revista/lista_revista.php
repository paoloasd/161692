
<div class="container print">
  <h2>Revista</h2>
  <a class="btn btn-info" href="revista.php?acao=novo">Novo</a>
  <?php if (count($registros)==0): ?>
    <p>Nenhum registro encontrado.</p>
  <?php else: ?>
    <table class="table table-hover table-stripped">
      <thead>
          <th>ID</th>
          <th>Ano Lançamento</th>
          <th>ISBN</th>
          <th>Valor</th>
          <th>Editora</th>
          <th>Status</th>
          <th>Ações</th>
      </thead>
      <tbody>
        <?php foreach ($registros as $linha): ?>
          <tr>
            <td><?= $linha['id']; ?></td>
            <td><?= $linha['ano_lancamento']; ?></td>
            <td><?= $linha['isbn']; ?></td>
            <td><?= $linha['valor']; ?></td>
            <td><?= $linha['editora']; ?></td>
            <td><?php if($linha['revista_completa']==1) echo "Revista Completa";
                      else echo "Revista Incompleta"; ?></td>
            <td>
              <a class="btn btn-warning btn-sm" href="revista.php?acao=buscar&id=<?php echo $linha['id']; ?>">Editar</a>
              <a class="btn btn-danger btn-sm" href="revista.php?acao=excluir&id=<?php echo $linha['id']; ?>">Excluir</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
