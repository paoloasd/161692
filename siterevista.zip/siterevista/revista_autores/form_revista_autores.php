<?php
    if(isset($registro)) $acao = "revista_autores.php?acao=atualizar&id=".$registro['id'];
    else $acao = "revista_autores.php?acao=gravar";
 ?>
<div class="container">
  <form class="" action="<?php echo $acao; ?>" method="post">
    <div class="from-group">
      <label for="descricao">Descrição</label>
      <input id="descricao" class="form-control" type="text" name="descricao"
        value="<?php if(isset($registro)) echo $registro['descricao']; ?>" required>
    </div>
    <div class="from-group">
      <label for="pagina">Página</label>
      <input id="pagina" class="form-control" type="number" name="pagina"
        value="<?php if(isset($registro)) echo $registro['pagina']; ?>" required>
    </div>
    <div class="from-group">
      <label for="id_autores">Autores</label>
      <select class="form-control" name="id_autores" required>
        <option value="">Escolha um item na lista</option>
        <?php foreach ($lista_autores as $item): ?>
          <option value="<?php echo $item['id']; ?>"
            <?php if(isset($registro) && $registro['id_autores']==$item['id']) echo "selected";?>>
            <?php echo 'revista : ' . $item['revista'] . ' | autores: ' . $item['escritor']; ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-check">
      <input id="completa" class="form-check-input" type="checkbox" name="lido"
        <?php if(isset($registro) && $registro['lido']==1) echo "checked"; ?>>
      <label class="form-check-label" for="completa"> Revista Completa </label>
    </div>
    <br>
    <button class="btn btn-info" type="submit">Enviar</button>
  </form>
</div>
