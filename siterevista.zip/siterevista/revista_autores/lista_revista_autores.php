
<div class="container print">
  <h2>Revista Autores</h2>
  <a class="btn btn-info" href="revista_autores.php?acao=novo">Novo</a>
  <?php if (count($registros)==0): ?>
    <p>Nenhum registro encontrado.</p>
  <?php else: ?>
    <table class="table table-hover table-stripped">
      <thead>
          <th>ID</th>
          <th>Descrição</th>
          <th>Página</th>
          <th>Lido</th>
          <th>Ações</th>
      </thead>
      <tbody>
        <?php foreach ($registros as $linha): ?>
          <tr>
            <td><?= $linha['id']; ?></td>
            <td><?= $linha['descricao']; ?></td>
            <td><?= $linha['pagina']; ?></td>
            <td><?php if($linha['lido']==1) echo "Completa";
                      else echo "Incompleta"; ?></td>
            <td>
                <a class="btn btn-warning btn-sm" href="revista_autores.php?acao=buscar&id=<?php echo $linha['id']; ?>">Editar</a>
                <a class="btn btn-danger btn-sm" href="revista_autores.php?acao=excluir&id=<?php echo $linha['id']; ?>">Excluir</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
